package protec.pl.protecabasvol2;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import android.widget.RemoteViews;

import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.RemoteMessage;


public class FirebaseMessagingService extends com.google.firebase.messaging.FirebaseMessagingService {
    public static String database;
    public static String password;
    @Override
    public void
    onMessageReceived(RemoteMessage remoteMessage) {

        if (remoteMessage.getData() != null) {
            Log.d("ON MESSAGE", "RECEIVED");
            String title =  remoteMessage.getData().get("title");
            String body = remoteMessage.getData().get("body");
            showNotification(title, body);
        }
    }

    public static String getDatabase() {
        return database;
    }

    public static String getPassword() {
        return password;
    }

    public static void setDBandPassword(String databaseLocal, String passwordLocal){
        database = databaseLocal;
        password = passwordLocal;
    }

    // Method to get the custom Design for the display of notification.
    private RemoteViews getCustomDesign(String title, String message) {
        RemoteViews remoteViews = new RemoteViews( getApplicationContext().getPackageName(), R.layout.push_notifications);
        remoteViews.setTextViewText(R.id.title, title);
        remoteViews.setTextViewText(R.id.message, message);
        remoteViews.setImageViewResource(R.id.icon, R.drawable.protec_logo_szare);
        return remoteViews;
    }

    // Method to display the notifications
    public void showNotification(String title, String message) {
      ///  Log.d("DATA ", "TEST");
       // Log.d("PASSWORD333" , getPassword());
       // Log.d("DATABSE" , getDatabase());
        if(getPassword() == null) {
            Log.d("REDIRECTED", "TO LOGIN");
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
        else {
            Log.d("STAYED", "HERE IN  MENU");
            Intent intent = new Intent(this, Menu.class);
            intent.putExtra("password", getPassword());
            intent.putExtra("database", getDatabase());
            String channel_id = "notification_channel";
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_ONE_SHOT);
            NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), channel_id).setSmallIcon(R.drawable.protec_logo_szare).setAutoCancel(true)
                    .setVibrate(new long[]{1000, 1000, 1000, 1000, 1000}).setOnlyAlertOnce(true).setContentIntent(pendingIntent);

            //Check version for custom Design implementation
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                builder = builder.setContent(getCustomDesign(title, message));
            }
            else {
                builder = builder.setContentTitle(title).setContentText(message).setSmallIcon(R.drawable.protec_logo_szare);
            }

            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { NotificationChannel notificationChannel = new NotificationChannel(channel_id, "web_app", NotificationManager.IMPORTANCE_HIGH);
                notificationManager.createNotificationChannel(notificationChannel);
            }
            Log.d("SOME OTHER", "TEST");
            notificationManager.notify(0, builder.build());
        }
    }
}
